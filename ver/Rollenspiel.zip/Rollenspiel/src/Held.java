/**
 * @author Sven Ibe
 */
public class Held {
    private static int gewonneneKaempfe;
    
    public static int erhoeheSiege () {
        return gewonneneKaempfe++;
    }
    
    private int staerke;
    private int angriffswert;
    private int lebenspunkte;
    private int verloreneKaempfe;
    private Waffe waffe;
    private String name;
    
    public Held (String pName, int pLebenspunkte, Waffe pWaffe) {
        name = pName;
        lebenspunkte = pLebenspunkte;
        waffe = pWaffe;
    }

    public int angriffswertBerechnen () {
        if (waffe != null) {
            staerke = Wuerfel.wuerfeln(6);
            angriffswert = staerke + waffe.getBonus();
        }
        return angriffswert; 
    }
    
    public int verliereLebenspunkt () {
        if (lebenspunkte != 0) {
            lebenspunkte--;
        } else {
            lebenspunkte = 0;
            verloreneKaempfe++;
            System.out.println("Der Held ist gestorben!");
            Spiel.setSpielBeendet(true);
        }
        return lebenspunkte;
    }
    
    public int getAngriffswert () {
        return angriffswert;
    }

    public String getName () {
        return name;
    }
    
    public int getLebenspunkte () {
        return lebenspunkte;
    }
    
    public int getGewonneneKaempfe () {
        return gewonneneKaempfe;
    }
    
    public int getVerloreneKaempfe () {
        return verloreneKaempfe;
    }
}
