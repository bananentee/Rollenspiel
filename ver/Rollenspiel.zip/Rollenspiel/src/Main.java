public class Main {
    private static Spiel spiel;

    public static void main(String[] args) {
	// write your code here
        spiel = new Spiel();
    }
}
