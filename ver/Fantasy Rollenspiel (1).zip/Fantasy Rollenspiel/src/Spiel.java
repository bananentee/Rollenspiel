import java.util.Scanner;
/**
 * @author Sven Ibe
 * @version 0.2
 */
public class Spiel {
    private static boolean spielBeendet = false;
    
    public static void setSpielBeendet (boolean pSpielbeendet) {
        spielBeendet = pSpielbeendet;
    }
    
    private int anzahlRunden;    
    private Held ritter;
    private Monster drache;
    private Scanner in = new Scanner(System.in);
    
    public Spiel() {
        erstelleHeld();
        erstelleMonster();
        spielStart();
    }
    
    public void showStats () {
        System.out.println("---------------------");
        System.out.println("Anzahl der Runden: " + anzahlRunden);
        System.out.println("gewonnene Kämpfe: " + ritter.getGewonneneKaempfe());
        System.out.println("verlorene Kämpfe: " + ritter.getVerloreneKaempfe());
        System.out.println("---------------------");
    }
    
    /**
     * Die Methode <code>spielStart</code> ist die wichtigste Methode des Spiels.
     * Zunächst wird <code>anzahlRunden</code> erhöht, um anzugeben, dass ein neuer Kampf gestartet wird.
     * Es wird geprüft, dass das Spiel noch nicht beendet ist. Falls dieser beendet ist, wird es in der Konsole gemeldet. 
     * Falls <code>spielBeendet</code> nicht wahr ist, werden die Angriffswerte der Objekte der Klassen Held und Monster berechnet. 
     * Anschließend wird der Kampf mit der Methode <code>Kampfregel.kampf</code> aufgerufen. 
     */
    private void spielStart () {
        anzahlRunden++;
        if (!spielBeendet) {
            ritter.angriffswertBerechnen();
            drache.angriffswertBerechnen();
            Kampfregel.kampf(ritter,drache);
        } else {
            System.out.println("Der Kampf ist beendet!");
            showStats();
        }
    }
    
    private void erstelleHeld () {
        System.out.println("Name des Helden: ");
        String nameHeld = in.nextLine();
        System.out.println("Lebenspunkte des Helden: ");
        int lebenspunkteHeld = in.nextInt();
        ritter = new Held(nameHeld,lebenspunkteHeld, new Waffe("Stahl",0));
        System.out.println("--------------------------");
        System.out.println("Neuer Held wurde erstellt!");
        System.out.println("Name: " + nameHeld);
        System.out.println("Anzahl der Lebenspunkte: " + lebenspunkteHeld);
        System.out.println("--------------------------");
    }
    
    private void erstelleMonster () {
        System.out.println("Lebenspunkte des Monsters: ");
        int lebenspunkteMonster = in.nextInt();
        drache = new Monster(lebenspunkteMonster);
        System.out.println("--------------------------");
        System.out.println("Neues Monster wurde erstellt!");
        System.out.println("Anzahl der Lebenspunkte: " + lebenspunkteMonster);
        System.out.println("--------------------------");
    }
    
    public void reset () {
        if (!spielBeendet) {
            erstelleHeld();
            erstelleMonster();
            spielStart();
        }
    }
}