/**
 * @author Sven Ibe
 */
public class Krieger extends Held{
    
    private int ausdauer;
    private Waffe waffe;
    
    public Krieger (String pName, int pLebenspunkte, Waffe pWaffe, int pAusdauer) {
        super(pName,pLebenspunkte,pWaffe);
        waffe = pWaffe;
        ausdauer = pAusdauer;
    }
    
    public int angriffswertBerechnen () {
        return super.angriffswertBerechnen();
    }
}
