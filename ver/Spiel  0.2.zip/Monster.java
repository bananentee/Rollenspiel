/**
 * @author Sven Ibe
 */
public class Monster {
    
    private int angriffswert;
    private int lebenspunkte;
    
    Monster (int pLebenspunkte) {
        lebenspunkte = pLebenspunkte;
    }
    
    public void angriffswertBerechnen () {
        angriffswert = Wuerfel.wuerfeln(10);
    }
    
    public int verliereLebenspunkt () {
        if (lebenspunkte > 0) {
            lebenspunkte--;
        } else {
            lebenspunkte = 0;
            Held.erhöheSiege();
            System.out.println("Der Held hat das Monster besiegt!");
            Spiel.setSpielBeendet(true);
        }
        return lebenspunkte;
    }
    
    public int getAngriffswert () {
        return angriffswert;
    }
    
    public int getLebenspunkte () {
        return lebenspunkte;
    }
}
