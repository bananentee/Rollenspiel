/**
 * @author Sven Ibe
 */
public class Zauberer extends Held{
    
    private int zauberkraft;
    
    Zauberer (String pName, int pLebenspunkte, int pZauberkraft) {
        super(pName,pLebenspunkte, null);
        zauberkraft = pZauberkraft;
    }
    
    public void heilen () {
        //TODO
    }
}
